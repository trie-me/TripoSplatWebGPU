# Napkinmatic3D

A small React canvas animation for illustrating **image-to-mesh emergence**.

The component renders a static, matching 2D projection on a paper plane, then animates the corresponding polyhedron upward through an infinite geometric clipping plane.

## Install locally

Copy `src/Napkinmatic3D.jsx` into your project, or publish this folder as an npm package.

```jsx
import { Napkinmatic3D } from "./Napkinmatic3D";

export default function Example() {
  return (
    <Napkinmatic3D
      easing="easeOutElastic"
      duration={1900}
    />
  );
}
```

## Optional tween panel

```jsx
<Napkinmatic3D showPanel />
```

The panel is excluded from the rendered interface unless `showPanel` is true.

## Imperative control

```jsx
import { useRef } from "react";
import { Napkinmatic3D } from "./Napkinmatic3D";

export default function Example() {
  const animation = useRef(null);

  return (
    <>
      <Napkinmatic3D
        ref={animation}
        showPlayButton={false}
      />
      <button onClick={() => animation.current?.play()}>
        Generate
      </button>
    </>
  );
}
```

The ref exposes:

- `play({ randomize?: boolean })`
- `reset()`
- `randomize()`
- `getScene()`

## Props

| Prop | Default | Purpose |
|---|---:|---|
| `autoPlay` | `false` | Play once after mounting |
| `duration` | `1900` | Animation duration in milliseconds |
| `easing` | `"easeOutElastic"` | Default tween |
| `showPanel` | `false` | Include tween-testing panel |
| `showPlayButton` | `true` | Include built-in play button |
| `randomizeOnPlay` | `false` | Generate a new mesh per play |
| `shape` | random | Restrict to `Tetrahedron`, `Octahedron`, `Cube`, or `Icosahedron` |
| `pageColor` | `#fbf7ed` | Paper fill |
| `projectionColor` | dark translucent | Static projection line color |
| `onComplete(scene)` | | Completion callback |
| `onSceneChange(scene)` | | Randomization callback |

## Performance decisions

- One visible `<canvas>`.
- Static paper and 2D projection are cached in an offscreen canvas.
- The animation loop redraws only the cached static layer and clipped dynamic mesh.
- Device pixel ratio is capped at 2.
- `ResizeObserver` redraws only when necessary.
- No external animation or geometry dependencies.
- `requestAnimationFrame` is canceled on unmount, reset, and replay.
- Geometry and edge topology are generated only when the scene changes.

## Package exports

```js
import { Napkinmatic3D, EASINGS } from "napkinmatic3d";
```
