import React, {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
} from "react";

const PHI = (1 + Math.sqrt(5)) / 2;

const SHAPES = Object.freeze([
  {
    name: "Tetrahedron",
    vertices: [[1,1,1],[-1,-1,1],[-1,1,-1],[1,-1,-1]],
    faces: [[0,1,2],[0,3,1],[0,2,3],[1,3,2]],
  },
  {
    name: "Octahedron",
    vertices: [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],
    faces: [[0,2,4],[4,2,1],[1,2,5],[5,2,0],[0,4,3],[4,1,3],[1,5,3],[5,0,3]],
  },
  {
    name: "Cube",
    vertices: [
      [-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],
      [-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1],
    ],
    faces: [
      [0,1,2],[0,2,3],[4,6,5],[4,7,6],
      [0,4,5],[0,5,1],[1,5,6],[1,6,2],
      [2,6,7],[2,7,3],[3,7,4],[3,4,0],
    ],
  },
  {
    name: "Icosahedron",
    vertices: [
      [-1,PHI,0],[1,PHI,0],[-1,-PHI,0],[1,-PHI,0],
      [0,-1,PHI],[0,1,PHI],[0,-1,-PHI],[0,1,-PHI],
      [PHI,0,-1],[PHI,0,1],[-PHI,0,-1],[-PHI,0,1],
    ],
    faces: [
      [0,11,5],[0,5,1],[0,1,7],[0,7,10],[0,10,11],
      [1,5,9],[5,11,4],[11,10,2],[10,7,6],[7,1,8],
      [3,9,4],[3,4,2],[3,2,6],[3,6,8],[3,8,9],
      [4,9,5],[2,4,11],[6,2,10],[8,6,7],[9,8,1],
    ],
  },
]);

export const EASINGS = Object.freeze({
  linear: t => t,
  easeOutCubic: t => 1 - Math.pow(1 - t, 3),
  easeOutQuint: t => 1 - Math.pow(1 - t, 5),
  easeInOutCubic: t =>
    t < 0.5 ? 4*t*t*t : 1 - Math.pow(-2*t + 2, 3) / 2,
  easeOutBack: t => {
    const c1 = 1.28;
    const c3 = c1 + 1;
    return 1 + c3*Math.pow(t - 1, 3) + c1*Math.pow(t - 1, 2);
  },
  easeOutElastic: t => {
    if (t === 0 || t === 1) return t;
    const c4 = (2*Math.PI)/3;
    return Math.pow(2, -10*t)*Math.sin((t*10 - 0.75)*c4) + 1;
  },
});

const EASING_OPTIONS = Object.freeze([
  ["linear", "Linear"],
  ["easeOutCubic", "Ease out cubic"],
  ["easeOutQuint", "Ease out quint"],
  ["easeInOutCubic", "Ease in-out cubic"],
  ["easeOutBack", "Ease out back"],
  ["easeOutElastic", "Ease out elastic"],
]);

const clamp01 = value => Math.max(0, Math.min(1, value));
const random = (min, max) => min + Math.random()*(max - min);

function normalizeVertices(vertices) {
  const radius = Math.max(...vertices.map(([x,y,z]) => Math.hypot(x,y,z)));
  return vertices.map(([x,y,z]) => [x/radius,y/radius,z/radius]);
}

function edgesFromFaces(faces) {
  const edges = new Set();
  for (const face of faces) {
    for (let i = 0; i < face.length; i += 1) {
      const a = face[i];
      const b = face[(i + 1) % face.length];
      edges.add(`${Math.min(a,b)}-${Math.max(a,b)}`);
    }
  }
  return [...edges].map(edge => edge.split("-").map(Number));
}

function rotate([x,y,z], ax, ay, az) {
  const cx = Math.cos(ax), sx = Math.sin(ax);
  const cy = Math.cos(ay), sy = Math.sin(ay);
  const cz = Math.cos(az), sz = Math.sin(az);
  const y1 = y*cx - z*sx;
  const z1 = y*sx + z*cx;
  const x2 = x*cy + z1*sy;
  const z2 = -x*sy + z1*cy;
  return [x2*cz - y1*sz, x2*sz + y1*cz, z2];
}

function createScene(shapeName) {
  const choices = shapeName
    ? SHAPES.filter(shape => shape.name === shapeName)
    : SHAPES;
  const source = choices[Math.floor(Math.random()*choices.length)] ?? SHAPES[0];
  const rotation = {
    x: random(-0.55,-0.18),
    y: random(0.25,1.25),
    z: random(-0.18,0.18),
  };

  return {
    name: source.name,
    faces: source.faces,
    edges: edgesFromFaces(source.faces),
    vertices: normalizeVertices(source.vertices).map(vertex =>
      rotate(vertex,rotation.x,rotation.y,rotation.z)
    ),
    hue: Math.floor(random(195,250)),
  };
}

function project([x,y,z], width, height) {
  const scale = Math.min(width,height)*0.225;
  const perspective = 1 + z*0.12;
  return [
    width/2 + x*scale*perspective,
    height*0.59 + z*scale*0.54 - y*scale,
    z,
  ];
}

function intersectPlane(a,b) {
  const t = a[1]/(a[1] - b[1]);
  return [
    a[0] + (b[0] - a[0])*t,
    0,
    a[2] + (b[2] - a[2])*t,
  ];
}

function clipAbovePage(polygon) {
  const output = [];
  for (let i = 0; i < polygon.length; i += 1) {
    const current = polygon[i];
    const previous = polygon[(i + polygon.length - 1)%polygon.length];
    const currentInside = current[1] >= 0;
    const previousInside = previous[1] >= 0;

    if (currentInside) {
      if (!previousInside) output.push(intersectPlane(previous,current));
      output.push(current);
    } else if (previousInside) {
      output.push(intersectPlane(previous,current));
    }
  }
  return output;
}

function pagePath(ctx,w,h) {
  ctx.beginPath();
  ctx.moveTo(w*0.29,h*0.36);
  ctx.lineTo(w*0.71,h*0.36);
  ctx.lineTo(w*0.91,h*0.84);
  ctx.lineTo(w*0.09,h*0.84);
  ctx.closePath();
}

function drawPage(ctx,w,h,pageColor,lineColor) {
  pagePath(ctx,w,h);
  ctx.fillStyle = pageColor;
  ctx.fill();
  ctx.strokeStyle = "#d8d0bf";
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.save();
  pagePath(ctx,w,h);
  ctx.clip();
  ctx.strokeStyle = "rgba(76,94,112,.055)";

  for (let row = 0; row < 14; row += 1) {
    const t = row/13;
    const y = h*(0.36 + t*0.48);
    const left = w*(0.29 - t*0.20);
    const right = w*(0.71 + t*0.20);
    ctx.beginPath();
    ctx.moveTo(left,y);
    ctx.lineTo(right,y);
    ctx.stroke();
  }

  for (let col = -8; col <= 8; col += 1) {
    ctx.beginPath();
    ctx.moveTo(w*0.5 + col*w*0.026,h*0.36);
    ctx.lineTo(w*0.5 + col*w*0.051,h*0.84);
    ctx.stroke();
  }

  ctx.strokeStyle = lineColor;
  ctx.lineWidth = 1.25;
  ctx.lineJoin = "round";
  ctx.restore();
}

function drawProjection(ctx,scene,w,h,lineColor) {
  const flat = scene.vertices.map(([x,,z]) => project([x,0,z],w,h));
  ctx.save();
  pagePath(ctx,w,h);
  ctx.clip();
  ctx.strokeStyle = lineColor;
  ctx.lineWidth = 1.25;
  ctx.lineJoin = "round";

  for (const [a,b] of scene.edges) {
    ctx.beginPath();
    ctx.moveTo(flat[a][0],flat[a][1]);
    ctx.lineTo(flat[b][0],flat[b][1]);
    ctx.stroke();
  }
  ctx.restore();
}

function drawStaticLayer(canvas,scene,width,height,dpr,pageColor,lineColor) {
  canvas.width = Math.round(width*dpr);
  canvas.height = Math.round(height*dpr);
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr,0,0,dpr,0,0);
  ctx.clearRect(0,0,width,height);
  drawPage(ctx,width,height,pageColor,lineColor);
  drawProjection(ctx,scene,width,height,lineColor);
}

function drawMesh(ctx,scene,vertices,w,h) {
  const sortable = [];
  for (let index = 0; index < scene.faces.length; index += 1) {
    const face = scene.faces[index];
    const polygon = clipAbovePage(face.map(i => vertices[i]));
    if (polygon.length < 3) continue;
    let depth = 0;
    for (const point of polygon) depth += point[2];
    sortable.push({polygon,index,depth:depth/polygon.length});
  }
  sortable.sort((a,b) => a.depth - b.depth);

  for (const {polygon,index} of sortable) {
    const first = project(polygon[0],w,h);
    ctx.beginPath();
    ctx.moveTo(first[0],first[1]);

    for (let i = 1; i < polygon.length; i += 1) {
      const point = project(polygon[i],w,h);
      ctx.lineTo(point[0],point[1]);
    }
    ctx.closePath();
    ctx.fillStyle = `hsla(${scene.hue - index*2},24%,${84 - index*0.8}%,.86)`;
    ctx.strokeStyle = "rgba(16,16,16,.85)";
    ctx.lineWidth = 1.2;
    ctx.lineJoin = "round";
    ctx.fill();
    ctx.stroke();
  }
}

function Curve({ easing }) {
  const fn = EASINGS[easing] ?? EASINGS.easeOutElastic;
  const points = Array.from({length:41},(_,index) => {
    const t = index/40;
    return `${8 + t*144},${70 - fn(t)*58}`;
  }).join(" ");

  return (
    <svg className="nm3d-curve" viewBox="0 0 160 78" aria-hidden="true">
      <line x1="8" y1="70" x2="152" y2="70" />
      <line x1="8" y1="70" x2="8" y2="12" />
      <polyline points={points} />
    </svg>
  );
}

export const Napkinmatic3D = forwardRef(function Napkinmatic3D({
  autoPlay = false,
  className = "",
  duration: initialDuration = 1900,
  easing: initialEasing = "easeOutElastic",
  pageColor = "#fbf7ed",
  projectionColor = "rgba(20,20,20,.72)",
  randomizeOnPlay = false,
  shape,
  showPanel = false,
  showPlayButton = true,
  onComplete,
  onSceneChange,
}, ref) {
  const canvasRef = useRef(null);
  const staticCanvasRef = useRef(document.createElement("canvas"));
  const rafRef = useRef(0);
  const startRef = useRef(0);
  const mountedRef = useRef(true);

  const [scene,setScene] = useState(() => createScene(shape));
  const [status,setStatus] = useState("idle");
  const [duration,setDuration] = useState(initialDuration);
  const [easing,setEasing] = useState(initialEasing);

  const play = useCallback(({randomize = randomizeOnPlay} = {}) => {
    cancelAnimationFrame(rafRef.current);
    startRef.current = 0;
    if (randomize) {
      const next = createScene(shape);
      setScene(next);
      onSceneChange?.(next);
    }
    setStatus("playing");
  },[randomizeOnPlay,shape,onSceneChange]);

  const reset = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    startRef.current = 0;
    setStatus("idle");
  },[]);

  const randomize = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    startRef.current = 0;
    const next = createScene(shape);
    setScene(next);
    setStatus("idle");
    onSceneChange?.(next);
  },[shape,onSceneChange]);

  useImperativeHandle(ref,() => ({
    play,
    reset,
    randomize,
    getScene: () => scene,
  }),[play,reset,randomize,scene]);

  useEffect(() => {
    mountedRef.current = true;
    if (autoPlay) play();
    return () => {
      mountedRef.current = false;
      cancelAnimationFrame(rafRef.current);
    };
  },[]); // intentional one-time autoplay

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d",{alpha:true});
    const dpr = Math.min(window.devicePixelRatio || 1,2);
    let width = 0;
    let height = 0;

    const rebuildStatic = () => {
      drawStaticLayer(
        staticCanvasRef.current,
        scene,
        width,
        height,
        dpr,
        pageColor,
        projectionColor
      );
    };

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      canvas.width = Math.round(width*dpr);
      canvas.height = Math.round(height*dpr);
      ctx.setTransform(dpr,0,0,dpr,0,0);
      rebuildStatic();
    };

    const render = (time = 0) => {
      ctx.clearRect(0,0,width,height);
      ctx.drawImage(staticCanvasRef.current,0,0,width,height);

      let raw = status === "complete" ? 1 : 0;
      if (status === "playing") {
        if (!startRef.current) startRef.current = time;
        raw = clamp01((time - startRef.current)/duration);
      }

      const easingFn = EASINGS[easing] ?? EASINGS.easeOutElastic;
      const centerY = -1.25 + easingFn(raw)*2.55;
      const emerging = scene.vertices.map(([x,y,z]) => [x,y + centerY,z]);
      drawMesh(ctx,scene,emerging,width,height);

      if (status === "playing" && raw < 1) {
        rafRef.current = requestAnimationFrame(render);
      } else if (status === "playing" && mountedRef.current) {
        startRef.current = 0;
        setStatus("complete");
        onComplete?.(scene);
      }
    };

    resize();
    render();

    const observer = new ResizeObserver(() => {
      resize();
      render();
    });
    observer.observe(canvas);

    return () => {
      observer.disconnect();
      cancelAnimationFrame(rafRef.current);
    };
  },[scene,status,duration,easing,pageColor,projectionColor,onComplete]);

  return (
    <div className={`nm3d ${showPanel ? "nm3d--panel" : ""} ${className}`}>
      <style>{`
        .nm3d,.nm3d *{box-sizing:border-box}
        .nm3d{width:100%;display:grid;grid-template-columns:minmax(0,1fr);gap:16px;align-items:center;font-family:Inter,system-ui,sans-serif;color:#181818}
        .nm3d--panel{grid-template-columns:minmax(0,1fr) 250px}
        .nm3d-stage{min-width:0;display:grid;justify-items:center;gap:10px}
        .nm3d-canvas{display:block;width:100%;aspect-ratio:16/10}
        .nm3d-play{width:58px;height:58px;display:grid;place-items:center;padding:0;border:1px solid #1c1c1c;border-radius:999px;background:#fffdf7;cursor:pointer}
        .nm3d-play:disabled{opacity:.45;cursor:default}
        .nm3d-play svg{width:22px;height:22px;fill:#181818}
        .nm3d-panel{display:grid;gap:14px;padding:16px;border:1px solid #d8d0bf;border-radius:12px;background:rgba(255,253,247,.84)}
        .nm3d-panel h3{margin:0;font-size:14px}
        .nm3d-field{display:grid;gap:6px;font-size:12px;font-weight:650}
        .nm3d-field select,.nm3d-panel button{min-height:36px;border:1px solid #cfc6b4;border-radius:8px;background:#fffdf7;color:#181818;padding:0 9px;font:inherit}
        .nm3d-range-head{display:flex;justify-content:space-between}
        .nm3d-field input{width:100%}
        .nm3d-curve{width:100%;height:84px;background:rgba(255,255,255,.55);border-radius:8px}
        .nm3d-curve line{stroke:rgba(20,20,20,.2);stroke-width:1}
        .nm3d-curve polyline{fill:none;stroke:#181818;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
        @media(max-width:760px){.nm3d--panel{grid-template-columns:1fr}.nm3d-panel{width:min(100%,480px);justify-self:center}}
      `}</style>

      <div className="nm3d-stage">
        <canvas className="nm3d-canvas" ref={canvasRef} />
        {showPlayButton && (
          <button
            className="nm3d-play"
            type="button"
            onClick={() => play()}
            disabled={status === "playing"}
            aria-label="Play image-to-mesh animation"
          >
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M8 5v14l11-7z" />
            </svg>
          </button>
        )}
      </div>

      {showPanel && (
        <aside className="nm3d-panel">
          <h3>Animation tween</h3>

          <label className="nm3d-field">
            Easing
            <select
              value={easing}
              onChange={event => {
                setEasing(event.target.value);
                setStatus("idle");
              }}
            >
              {EASING_OPTIONS.map(([value,label]) => (
                <option key={value} value={value}>{label}</option>
              ))}
            </select>
          </label>

          <Curve easing={easing} />

          <label className="nm3d-field">
            <span className="nm3d-range-head">
              <span>Duration</span>
              <span>{duration} ms</span>
            </span>
            <input
              type="range"
              min="500"
              max="4000"
              step="100"
              value={duration}
              onChange={event => {
                setDuration(Number(event.target.value));
                setStatus("idle");
              }}
            />
          </label>

          <button type="button" onClick={() => play({randomize:false})}>
            Replay same mesh
          </button>
          <button type="button" onClick={randomize}>
            New mesh and projection
          </button>
        </aside>
      )}
    </div>
  );
});
