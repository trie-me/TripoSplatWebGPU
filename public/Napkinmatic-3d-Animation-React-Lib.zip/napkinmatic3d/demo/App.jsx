import React, { useRef } from "react";
import { Napkinmatic3D } from "../src/index.js";

export default function App() {
  const animation = useRef(null);

  return (
    <main style={{
      minHeight: "100vh",
      display: "grid",
      placeItems: "center",
      padding: 24,
      background: "#f1eee7",
    }}>
      <div style={{ width: "min(96vw, 1100px)" }}>
        <Napkinmatic3D
          ref={animation}
          showPanel
          easing="easeOutElastic"
          duration={1900}
        />
      </div>
    </main>
  );
}
